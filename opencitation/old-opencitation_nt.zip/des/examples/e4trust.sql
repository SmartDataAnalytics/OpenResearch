-- SQL Debugger
-- November 2011
-- Example 4
--
-- Trust file
create view u(a) as select * from s where a>=1 or a>0;